// OpenSea 메인 페이지 로직
console.log("OpenSea page loaded");

// 페이지 로드 시 자동으로 OpenSea로 이동
window.location.href = "https://opensea.io/";
