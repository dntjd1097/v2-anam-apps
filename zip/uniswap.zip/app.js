// Uniswap 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Uniswap mini app started');
  },
  
  onShow() {
    console.log('Uniswap mini app shown');
  },
  
  onHide() {
    console.log('Uniswap mini app hidden');
  }
};