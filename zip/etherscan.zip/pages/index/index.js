// Etherscan 메인 페이지 로직
console.log("Etherscan page loaded");

// 페이지 로드 시 자동으로 Etherscan으로 이동
window.location.href = "https://etherscan.io/";
