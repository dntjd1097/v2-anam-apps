// Seoul Culture 메인 페이지 로직
console.log('Seoul Culture page loaded');

// 페이지 로드 시 자동으로 Seoul Culture로 이동
window.location.href = "https://cultureseoul.co.kr/2025/en/";